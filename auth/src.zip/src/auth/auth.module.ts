import { Module } from '@nestjs/common';
import { ConfigModule, ConfigService } from '@nestjs/config';
import { HttpModule } from '@nestjs/axios';
import { AuthService } from './auth.service';
import { UsersModule } from '../users/users.module';
import { JwtModule } from '@nestjs/jwt';
import { AuthController } from './auth.controller';
import { GuardsModule } from '../guards/guards.module';
import { TokenModule } from '../common/token.module';
import { SecurityModule } from '../common/security/security.module';
import { TwoFactorAuthModule } from '../2fa-auth/2fa-auth.module';


@Module({
  imports: [
    HttpModule,
    UsersModule,
    TokenModule,
    SecurityModule,
    GuardsModule,
    TwoFactorAuthModule,
    JwtModule.registerAsync({
      imports: [ConfigModule],
      useFactory: async (configService: ConfigService) => ({
        global: true,
        secret: configService.get<string>('JWT_SECRET') || 'your-secret-key',
        signOptions: { 
          expiresIn: configService.get<string>('JWT_ACCESS_EXPIRES_IN') || '24h' 
        },
      }),
      inject: [ConfigService],
    }),
  ],
  providers: [AuthService],
  controllers: [AuthController],
  exports: [AuthService],
})
export class AuthModule {} 