import { ApiProperty } from '@nestjs/swagger';
import {
  IsNotEmpty,
  IsNumber,
  IsString,
  IsOptional,
  Length,
  Matches,
} from 'class-validator';
import { Transform } from 'class-transformer';

export class CreateWorkLocationFileDto {
  @ApiProperty({
    description: 'ID-ul locației',
    example: 1,
  })
  @IsNumber({}, { message: 'ID-ul locației trebuie să fie un număr' })
  @IsNotEmpty({ message: 'ID-ul locației este obligatoriu' })
  @Transform(({ value }) => parseInt(value, 10))
  work_location_id: number;

  @ApiProperty({
    description: 'Numele fișierului',
    example: 'Contract_Locatie_2023.pdf',
    maxLength: 255,
  })
  @IsString({ message: 'Numele fișierului trebuie să fie un string' })
  @IsNotEmpty({ message: 'Numele fișierului este obligatoriu' })
  @Length(3, 255, { message: 'Numele fișierului trebuie să aibă între 3 și 255 de caractere' })
  @Matches(/^[a-zA-Z0-9._\-\săîâșțĂÎÂȘȚ]+\.(pdf|doc|docx|jpg|jpeg|png|txt|xlsx|xls)$/i, {
    message: 'Numele fișierului trebuie să aibă o extensie validă (.pdf, .doc, .docx, .jpg, .jpeg, .png, .txt, .xlsx, .xls)'
  })
  file_name: string;

  @ApiProperty({
    description: 'Tipul fișierului',
    example: 'Contract',
    maxLength: 100,
    enum: ['Contract', 'Autorizatie', 'Certificat', 'Poza', 'Plan', 'Document_Financiar', 'Altele'],
  })
  @IsString({ message: 'Tipul fișierului trebuie să fie un string' })
  @IsNotEmpty({ message: 'Tipul fișierului este obligatoriu' })
  @Length(2, 100, { message: 'Tipul fișierului trebuie să aibă între 2 și 100 de caractere' })
  file_type: string;

  @ApiProperty({
    description: 'Link-ul către fișier sau calea de stocare',
    example: '/files/locations/1/contract_locatie.pdf',
    maxLength: 255,
  })
  @IsString({ message: 'Link-ul fișierului trebuie să fie un string' })
  @IsNotEmpty({ message: 'Link-ul fișierului este obligatoriu' })
  @Length(5, 255, { message: 'Link-ul fișierului trebuie să aibă între 5 și 255 de caractere' })
  @Matches(/^(\/storage\/|\/files\/|https?:\/\/|\\\\server\\)/, {
    message: 'Link-ul trebuie să înceapă cu /storage/, /files/, http://, https:// sau \\\\server\\'
  })
  file_link: string;

  @ApiProperty({
    description: 'Conținutul fișierului în format base64 (opțional)',
    example: 'data:application/pdf;base64,JVBERi0xLjQKMSAwIG9iago8PAovVHlwZSAvQ2F0YWxvZwo...',
    required: false,
  })
  @IsOptional()
  @IsString({ message: 'Conținutul fișierului trebuie să fie un string' })
  file_content?: string;
}
