import { Injectable, NotFoundException, BadRequestException, Inject, ConflictException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { DeepPartial, Repository } from 'typeorm';
import { ClientProxy } from '@nestjs/microservices';
import { firstValueFrom } from 'rxjs';
import * as path from 'path';
import * as fs from 'fs';
import { WorkLocation } from '../locations/entity/work-location.entity';
import { WorkLocationTaskTemplate } from '../locations/entity/work-location-task-template.entity';
import { WorkLocationDepartments } from '../locations/entity/work-location-departments.entity';
import { WorkLocationDepartmentPositions } from '../locations/entity/work-location-department-positions.entity';
import { CreateWorkLocationDto } from './dto/create-work-location.dto';
import { UpdateWorkLocationDto } from './dto/update-work-location.dto';
import { CreateTaskTemplateAssignmentDto } from './dto/create-task-template-assignment.dto';
import { UpdateTaskTemplateAssignmentDto } from './dto/update-task-template-assignment.dto';
import { WorkLocationRevenue } from './entity/work-location-revenue.entity';
import { WorkLocationRevenuePoints } from './entity/work-location-revenue-points.entity';
import { WorkLocationManagerConfig } from './entity/work-location-manager-config.entity';
import { WorkLocationFiles } from './entity/work-location-files.entity';
import { CreateWorkLocationFileDto } from './dto/create-work-location-file.dto';

@Injectable()
export class LocationsService {
  constructor(
    @InjectRepository(WorkLocation) private readonly workLocationRepository: Repository<WorkLocation>,
    @InjectRepository(WorkLocationTaskTemplate) private readonly taskTemplateRepository: Repository<WorkLocationTaskTemplate>,
    @InjectRepository(WorkLocationDepartments) private readonly departmentsRepository: Repository<WorkLocationDepartments>,
    @InjectRepository(WorkLocationDepartmentPositions) private readonly positionsRepository: Repository<WorkLocationDepartmentPositions>,
    @InjectRepository(WorkLocationRevenue) private readonly revenueRepository: Repository<WorkLocationRevenue>,
    @InjectRepository(WorkLocationRevenuePoints) private readonly revenuePointsRepository: Repository<WorkLocationRevenuePoints>,
    @InjectRepository(WorkLocationManagerConfig) private readonly managerConfigRepository: Repository<WorkLocationManagerConfig>,
    @InjectRepository(WorkLocationFiles) private readonly filesRepository: Repository<WorkLocationFiles>,
    @Inject('NOTIFICATIONS_RMQ') private readonly notificationsClient: ClientProxy,
  ) {}

  private getLocationsFilesRootDir(): string {
    // Resolve to giurom root (one level above giurom-backend)
    // __dirname is .../giurom-backend/locations/src (dev with ts-node) or .../giurom-backend/locations/dist (prod)
    const repoRoot = path.resolve(__dirname, '../../../..');
    return path.join(repoRoot, 'files', 'locations');
  }

  private async sendLocationNotification(
    type: string,
    title: string,
    description: string,
    locationId: number,
    metadata?: any
  ): Promise<void> {
    try {
      await firstValueFrom(
        this.notificationsClient.emit({ cmd: 'locations.notification' }, {
          type,
          title,
          description,
          entity_id: locationId,
          entity_type: 'location',
          metadata,
          priority: 'medium',
        })
      );
    } catch (error) {
      console.error('Failed to send location notification:', error);
    }
  }

  async createWorkLocation(dto: CreateWorkLocationDto): Promise<WorkLocation> {
    const entity: WorkLocation = this.workLocationRepository.create(
      dto as unknown as Partial<WorkLocation>,
    ) as WorkLocation;
    const saved: WorkLocation = await this.workLocationRepository.save(entity as WorkLocation);
    
    // Send notification for new location
    await this.sendLocationNotification(
      'location_created',
      'Locație nouă adăugată',
      `A fost adăugată o nouă locație: ${saved.location_name}`,
      saved.id,
      { locationName: saved.location_name }
    );
    
    return saved;
  }

  async findAllWorkLocations(
    page = 1,
    limit = 10,
    companyId?: number,
    city?: string,
    search?: string,
  ): Promise<{ locations: WorkLocation[]; total: number; totalPages: number }> {
    const qb = this.workLocationRepository
      .createQueryBuilder('location')
      .leftJoinAndSelect('location.task_templates', 'task_templates');
    if (companyId) qb.where('location.company_id = :companyId', { companyId });
    if (city) qb.andWhere('location.city = :city', { city });
    if (search)
      qb.andWhere(
        'location.location_name LIKE :search OR location.address LIKE :search',
        { search: `%${search}%` },
      );
    const offset = (page - 1) * limit;
    const [locations, total] = await qb
      .orderBy('location.created_at', 'DESC')
      .skip(offset)
      .take(limit)
      .getManyAndCount();
    return { locations, total, totalPages: Math.ceil(total / limit) };
  }

  async findWorkLocationById(id: number): Promise<WorkLocation> {
    const workLocation = await this.workLocationRepository.findOne({
      where: { id },
      relations: ['task_templates'],
    });
    if (!workLocation)
      throw new NotFoundException(`Locația cu ID-ul ${id} nu a fost găsită`);
    return workLocation;
  }

  async findWorkLocationsByCompany(companyId: number): Promise<WorkLocation[]> {
    return await this.workLocationRepository.find({
      where: { company_id: companyId },
      relations: ['task_templates'],
      order: { id: 'DESC' },
    });
  }

  async updateWorkLocation(id: number, dto: UpdateWorkLocationDto): Promise<WorkLocation> {
    const workLocation = await this.findWorkLocationById(id);
    const oldName = workLocation.location_name;
    Object.assign(workLocation, dto);
    const updatedLocation = await this.workLocationRepository.save(workLocation as WorkLocation);
    
    // Send notification for updated location
    await this.sendLocationNotification(
      'location_updated',
      'Locație modificată',
      `Locația ${oldName} a fost modificată`,
      updatedLocation.id,
      { 
        oldName,
        newName: updatedLocation.location_name,
        updatedFields: Object.keys(dto)
      }
    );
    
    return updatedLocation;
  }

  async removeWorkLocation(id: number): Promise<void> {
    const workLocation = await this.findWorkLocationById(id);
    const locationName = workLocation.location_name;
    
    // Get related departments count
    const departmentsCount = await this.departmentsRepository.count({ 
      where: { work_location_id: id } as any 
    });
    
    // Get related revenue points count
    const revenuePointsCount = await this.revenuePointsRepository.count({ 
      where: { work_location_id: id } as any 
    });
    
    // Send notification for deleted location
    await this.sendLocationNotification(
      'location_deleted',
      'Locație ștearsă',
      `Locația ${locationName} a fost ștearsă (Departamente: ${departmentsCount}, Puncte: ${revenuePointsCount}, Angajați afectați)`,
      id,
      { 
        locationName,
        departmentsCount,
        revenuePointsCount
      }
    );
    
    await this.workLocationRepository.remove(workLocation as WorkLocation);
  }

  async createTaskTemplateAssignment(
    dto: CreateTaskTemplateAssignmentDto,
  ): Promise<WorkLocationTaskTemplate> {
    await this.findWorkLocationById(dto.location_id);
    const existing = await this.taskTemplateRepository.findOne({
      where: {
        location_id: dto.location_id,
        template_id: dto.template_id || 1,
        active: true,
      },
    });
    if (existing)
      throw new BadRequestException(
        `Template-ul ${dto.template_id || 1} este deja atribuit activ la această locație`,
      );
    const assignment: WorkLocationTaskTemplate = this.taskTemplateRepository.create({
      ...dto,
      assigned_at: new Date(),
    }) as WorkLocationTaskTemplate;
    return await this.taskTemplateRepository.save(
      assignment as WorkLocationTaskTemplate,
    );
  }

  async findAllTaskTemplateAssignments(
    page = 1,
    limit = 10,
    locationId?: number,
    templateId?: number,
    active?: boolean,
  ): Promise<{ assignments: WorkLocationTaskTemplate[]; total: number; totalPages: number }> {
    const qb = this.taskTemplateRepository
      .createQueryBuilder('assignment')
      .leftJoinAndSelect('assignment.work_location', 'work_location');
    if (locationId) qb.where('assignment.location_id = :locationId', { locationId });
    if (templateId) qb.andWhere('assignment.template_id = :templateId', { templateId });
    if (active !== undefined) qb.andWhere('assignment.active = :active', { active });
    const offset = (page - 1) * limit;
    const [assignments, total] = await qb
      .orderBy('assignment.assigned_at', 'DESC')
      .skip(offset)
      .take(limit)
      .getManyAndCount();
    return { assignments, total, totalPages: Math.ceil(total / limit) };
  }

  async findTaskTemplateAssignmentById(
    id: number,
  ): Promise<WorkLocationTaskTemplate> {
    const assignment = await this.taskTemplateRepository.findOne({
      where: { id },
      relations: ['work_location'],
    });
    if (!assignment)
      throw new NotFoundException(
        `Atribuirea cu ID-ul ${id} nu a fost găsită`,
      );
    return assignment;
  }

  async findTaskTemplateAssignmentsByLocation(
    locationId: number,
  ): Promise<WorkLocationTaskTemplate[]> {
    await this.findWorkLocationById(locationId);
    return await this.taskTemplateRepository.find({
      where: { location_id: locationId },
      relations: ['work_location'],
      order: { assigned_at: 'DESC' },
    });
  }

  // --- Departments ---
  async findDepartmentsByLocation(locationId: number): Promise<WorkLocationDepartments[]> {
    // Return departments directly; do not enforce location existence to avoid 404s when data is partially seeded
    return this.departmentsRepository.find({ where: { work_location_id: locationId } as any, order: { name: 'ASC' } as any });
  }

  async createDepartment(dto: { work_location_id: number; name: string; code: string; description?: string | null }) {
    const row = this.departmentsRepository.create({
      work_location_id: dto.work_location_id,
      name: dto.name,
      code: dto.code,
      description: dto.description ?? null,
    } as Partial<WorkLocationDepartments> as WorkLocationDepartments);
    return this.departmentsRepository.save(row);
  }

  async findPositionsByDepartment(departmentId: number): Promise<WorkLocationDepartmentPositions[]> {
    return this.positionsRepository.find({ where: { department_id: departmentId } as any, order: { name: 'ASC' } as any });
  }

  async createDepartmentPosition(dto: { department_id: number; name: string; code: string; description?: string | null }) {
    const row = this.positionsRepository.create({
      department_id: dto.department_id,
      name: dto.name,
      code: dto.code,
      description: dto.description ?? null,
    } as Partial<WorkLocationDepartmentPositions> as WorkLocationDepartmentPositions);
    return this.positionsRepository.save(row);
  }

  async updateTaskTemplateAssignment(
    id: number,
    dto: UpdateTaskTemplateAssignmentDto,
  ): Promise<WorkLocationTaskTemplate> {
    const assignment = await this.findTaskTemplateAssignmentById(id);
    Object.assign(assignment, dto);
    return await this.taskTemplateRepository.save(
      assignment as WorkLocationTaskTemplate,
    );
  }

  async removeTaskTemplateAssignment(id: number): Promise<void> {
    const assignment = await this.findTaskTemplateAssignmentById(id);
    await this.taskTemplateRepository.remove(assignment as WorkLocationTaskTemplate);
  }

  async deactivateTemplateAssignments(templateId: number): Promise<void> {
    await this.taskTemplateRepository.update(
      { template_id: templateId },
      { active: false },
    );
  }

  async toggleAssignmentStatus(
    id: number,
    active: boolean,
  ): Promise<WorkLocationTaskTemplate> {
    const assignment = await this.findTaskTemplateAssignmentById(id);
    assignment.active = active;
    return await this.taskTemplateRepository.save(
      assignment as WorkLocationTaskTemplate,
    );
  }

  async getLocationStatistics(): Promise<{
    total_locations: number;
    locations_by_company: { company_id: number; company_name: string; count: number }[];
    total_assignments: number;
    active_assignments: number;
  }> {
    const total_locations = await this.workLocationRepository.count();
    const total_assignments = await this.taskTemplateRepository.count();
    const active_assignments = await this.taskTemplateRepository.count({
      where: { active: true },
    });
    return {
      total_locations,
      locations_by_company: [],
      total_assignments,
      active_assignments,
    };
  }

  // --- Revenue points management ---
  async setRevenueIntervals(workLocationId: number, intervals: Array<{ min: number; max?: number | null; points: number }>) {
    const wl = await this.findWorkLocationById(workLocationId);
    await this.revenuePointsRepository.delete({ work_location_id: workLocationId } as any);
    const rows: DeepPartial<WorkLocationRevenuePoints>[] = intervals.map(i => ({
      work_location_id: workLocationId,
      min_revenue: i.min as any,
      max_revenue: (i.max ?? null) as any,
      points: i.points as any,
    }));
    return this.revenuePointsRepository.save(rows);
  }

  async getRevenueIntervals(workLocationId: number) {
    await this.findWorkLocationById(workLocationId);
    return this.revenuePointsRepository.find({
      where: { work_location_id: workLocationId } as any,
      order: { min_revenue: 'ASC' } as any,
    });
  }

  async setManagerPercent(workLocationId: number, managerPercent: number, _fallbackRevenuePerPoint?: number) {
    let cfg = await this.managerConfigRepository.findOne({ where: { work_location_id: workLocationId } as any });
    if (!cfg) {
      cfg = this.managerConfigRepository.create({
        work_location_id: workLocationId,
        manager_percent: managerPercent as any,
      } as Partial<WorkLocationManagerConfig> as WorkLocationManagerConfig);
    } else {
      cfg.manager_percent = managerPercent as any;
    }
    return this.managerConfigRepository.save(cfg);
  }

  async getManagerConfig(workLocationId: number) {
    await this.findWorkLocationById(workLocationId);
    return this.managerConfigRepository.findOne({ where: { work_location_id: workLocationId } as any });
  }

  async recordRevenue(workLocationId: number, revenueDate: string, revenueAmount: number) {
    // Always insert a new revenue row (allow multiple entries per day)
    await this.findWorkLocationById(workLocationId);
    const row = this.revenueRepository.create({
      work_location_id: workLocationId,
      revenue_date: revenueDate,
      revenue_amount: revenueAmount as any,
    } as Partial<WorkLocationRevenue> as WorkLocationRevenue);
    return this.revenueRepository.save(row);
  }

  async listRevenue(
    workLocationId: number,
    opts?: { startDate?: string; endDate?: string; page?: number; limit?: number },
  ) {
    await this.findWorkLocationById(workLocationId);
    const page = Math.max(1, Number(opts?.page || 1));
    const limit = Math.max(1, Math.min(200, Number(opts?.limit || 50)));
    const qb = this.revenueRepository
      .createQueryBuilder('rev')
      .where('rev.location_id = :workLocationId', { workLocationId })
      .orderBy('rev.revenue_date', 'DESC');

    if (opts?.startDate) qb.andWhere('rev.revenue_date >= :startDate', { startDate: opts.startDate });
    if (opts?.endDate) qb.andWhere('rev.revenue_date <= :endDate', { endDate: opts.endDate });

    const offset = (page - 1) * limit;
    const [items, total] = await qb.skip(offset).take(limit).getManyAndCount();
    return { revenues: items, total, totalPages: Math.ceil(total / limit) };
  }

  async getManagerPointsForDate(workLocationId: number, revenueDate: string) {
    const cfg = await this.managerConfigRepository.findOne({ where: { work_location_id: workLocationId } as any });
    if (!cfg) return { totalPoints: 0, managerPoints: 0, managerPercent: 0, breakdown: [] } as any;
    const revs = await this.revenueRepository.find({ where: { work_location_id: workLocationId, revenue_date: revenueDate } as any });
    if (!revs || revs.length === 0) return { totalPoints: 0, managerPoints: 0, managerPercent: Number(cfg.manager_percent), breakdown: [] } as any;
    const intervals = await this.revenuePointsRepository.find({ where: { work_location_id: workLocationId } as any, order: { min_revenue: 'ASC' } as any });
    let totalPoints = 0;
    let totalManagerPoints = 0;
    const breakdown: Array<{ amount: number; pointsPerUnit: number; interval: { min: number; max: number | null }; points: number; managerShare: number }> = [];
    for (const rev of revs) {
      let pointsPerUnit: number | null = null;
      let matched: { min: number; max: number | null } | null = null;
      for (const intv of intervals) {
        const minOk = Number(rev.revenue_amount) >= Number(intv.min_revenue);
        const maxOk = intv.max_revenue == null ? true : Number(rev.revenue_amount) <= Number(intv.max_revenue);
        if (minOk && maxOk) { pointsPerUnit = Number(intv.points); matched = { min: Number(intv.min_revenue), max: intv.max_revenue == null ? null : Number(intv.max_revenue) }; break; }
      }
      if (!pointsPerUnit || pointsPerUnit <= 0) continue;
      // Interpret pointsPerUnit as "amount per 1 point"
      const amount = Number(rev.revenue_amount);
      const pts = amount / pointsPerUnit;
      totalPoints += pts;
      const managerPts = pts * (Number(cfg.manager_percent) / 100);
      totalManagerPoints += managerPts;
      breakdown.push({ amount, pointsPerUnit, interval: matched as any, points: pts, managerShare: managerPts });
    }
    return { totalPoints, managerPoints: totalManagerPoints, managerPercent: Number(cfg.manager_percent), breakdown } as any;
  }

  // ==================== LOCATION FILES METHODS ====================

  // Creează un nou fișier pentru locație
  async createFile(createFileDto: CreateWorkLocationFileDto): Promise<WorkLocationFiles> {
    console.log('📥 Received createFileDto:', {
      work_location_id: createFileDto.work_location_id,
      file_name: createFileDto.file_name,
      file_type: createFileDto.file_type,
      has_content: !!createFileDto.file_content,
      content_length: createFileDto.file_content?.length || 0
    });
    
    // Verifică dacă locația există
    const location = await this.workLocationRepository.findOne({
      where: { id: createFileDto.work_location_id }
    });

    if (!location) {
      throw new NotFoundException(`Locația cu ID-ul ${createFileDto.work_location_id} nu a fost găsită`);
    }

    // Generate unique filename with timestamp
    const timestamp = new Date().toISOString().replace(/[:.]/g, '-').slice(0, -5);
    const fileExtension = createFileDto.file_name.split('.').pop() || 'txt';
    const baseFileName = createFileDto.file_name.replace(/\.[^/.]+$/, "") || 'file';
    const uniqueFileName = `${baseFileName}_${timestamp}.${fileExtension}`;

    console.log(`📝 Original: ${createFileDto.file_name}, Generated: ${uniqueFileName}`);

    // Update the file_link to use the unique filename
    const updatedFileLink = createFileDto.file_link.replace(createFileDto.file_name, uniqueFileName);

    // Create the directory if it doesn't exist
    const locationId = createFileDto.work_location_id?.toString() || 'unknown';
    console.log(`📁 Creating directory for location ID: ${locationId}`);
    const baseDir = this.getLocationsFilesRootDir();
    const fileDir = path.join(baseDir, locationId);
    if (!fs.existsSync(fileDir)) {
      fs.mkdirSync(fileDir, { recursive: true });
    }

    // If file content is provided (base64), save it to disk
    if (createFileDto.file_content) {
      try {
        const filePath = path.join(fileDir, uniqueFileName);
        
        // Extract base64 content from data URL (remove data:type;base64, prefix)
        let base64Data = createFileDto.file_content;
        if (base64Data.includes(',')) {
          base64Data = base64Data.split(',')[1];
        }
        
        console.log(`💾 Saving file with ${base64Data.length} base64 characters`);
        const buffer = Buffer.from(base64Data, 'base64');
        fs.writeFileSync(filePath, buffer);
        console.log(`✅ File saved to disk: ${filePath} (${buffer.length} bytes)`);
      } catch (error) {
        console.error('❌ Error saving file to disk:', error);
      }
    }

    // Verifică dacă există deja un fișier cu același nume pentru aceeași locație
    const existingFile = await this.filesRepository.findOne({
      where: {
        work_location_id: createFileDto.work_location_id,
        file_name: uniqueFileName
      }
    });

    if (existingFile) {
      throw new ConflictException(`Un fișier cu numele "${uniqueFileName}" există deja pentru această locație`);
    }

    // Create the file record with unique filename
    const file = this.filesRepository.create({
      ...createFileDto,
      file_name: uniqueFileName,
      file_link: updatedFileLink
    });

    const savedFile = await this.filesRepository.save(file);
    console.log(`✅ File record saved to database with ID: ${savedFile.id}`);
    
    return savedFile;
  }

  // Găsește un fișier după ID
  async findOneFile(id: number): Promise<WorkLocationFiles> {
    const file = await this.filesRepository.findOne({
      where: { id },
      relations: ['workLocation'],
    });

    if (!file) {
      throw new NotFoundException(`Fișierul cu ID-ul ${id} nu a fost găsit`);
    }

    return file;
  }

  // Găsește toate fișierele unei locații
  async findFilesByLocation(work_location_id: number): Promise<WorkLocationFiles[]> {
    const location = await this.workLocationRepository.findOne({
      where: { id: work_location_id }
    });

    if (!location) {
      throw new NotFoundException(`Locația cu ID-ul ${work_location_id} nu a fost găsită`);
    }

    return await this.filesRepository.find({
      where: { work_location_id },
      relations: ['workLocation'],
      order: { updated_at: 'DESC' },
    });
  }

  // Servește fișierul de pe disk
  async serveFile(file_id: number, forceDownload: boolean = false): Promise<{ data: string; mimeType: string; fileName: string; disposition: 'inline' | 'attachment' }> {
    try {
      console.log(`🔍 [serveFile] Starting to serve file with ID: ${file_id}, forceDownload: ${forceDownload}`);
      
      const file = await this.findOneFile(file_id);
      console.log(`📄 [serveFile] File metadata retrieved:`, {
        id: file.id,
        name: file.file_name,
        work_location_id: file.work_location_id,
        file_link: file.file_link
      });
      
      const baseDir = this.getLocationsFilesRootDir();
      console.log(`📁 [serveFile] Base directory: ${baseDir}`);
      
      const filePath = path.join(baseDir, file.work_location_id.toString(), file.file_name);
      console.log(`📁 [serveFile] Full file path: ${filePath}`);
      console.log(`📁 [serveFile] Path exists check: ${fs.existsSync(filePath)}`);
      
      // Check if directory exists
      const fileDir = path.join(baseDir, file.work_location_id.toString());
      console.log(`📁 [serveFile] Directory path: ${fileDir}`);
      console.log(`📁 [serveFile] Directory exists: ${fs.existsSync(fileDir)}`);
      
      if (fs.existsSync(fileDir)) {
        const filesInDir = fs.readdirSync(fileDir);
        console.log(`📁 [serveFile] Files in directory:`, filesInDir);
      }
      
      if (!fs.existsSync(filePath)) {
        console.error(`❌ [serveFile] File not found on disk: ${filePath}`);
        throw new NotFoundException(`Fișierul nu a fost găsit pe disk la calea: ${filePath}`);
      }
      
      const mimeType = this.getMimeType(file.file_name);
      console.log(`📋 [serveFile] MIME type determined: ${mimeType}`);
      
      const fileBuffer = fs.readFileSync(filePath);
      console.log(`✅ [serveFile] File read successfully: ${file.file_name} (${fileBuffer.length} bytes)`);

      return {
        data: fileBuffer.toString('base64'),
        mimeType,
        fileName: file.file_name,
        disposition: forceDownload ? 'attachment' : 'inline',
      };
    } catch (error) {
      console.error(`❌ [serveFile] Error serving file ${file_id}:`, error);
      console.error(`❌ [serveFile] Error message:`, error.message);
      console.error(`❌ [serveFile] Error stack:`, error.stack);
      throw error;
    }
  }

  // Determină tipul MIME bazat pe extensia fișierului
  private getMimeType(fileName: string): string {
    const extension = fileName.split('.').pop()?.toLowerCase();
    
    const mimeTypes: { [key: string]: string } = {
      'pdf': 'application/pdf',
      'doc': 'application/msword',
      'docx': 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
      'jpg': 'image/jpeg',
      'jpeg': 'image/jpeg',
      'png': 'image/png',
      'txt': 'text/plain',
      'xlsx': 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
      'xls': 'application/vnd.ms-excel',
    };
    
    return mimeTypes[extension || ''] || 'application/octet-stream';
  }

  // Șterge un fișier
  async removeFile(id: number): Promise<{ message: string }> {
    const file = await this.findOneFile(id);
    await this.filesRepository.delete(id);
    
    return {
      message: `Fișierul "${file.file_name}" al locației ${file.workLocation.location_name} a fost șters cu succes`,
    };
  }
} 